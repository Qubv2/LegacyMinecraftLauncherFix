package LZMA;

import java.io.IOException;

public class LzmaException extends IOException {
  private static final long serialVersionUID = 3689351022372206390L;
  
  public LzmaException() {}
  
  public LzmaException(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\Users\Ziel0ny\Desktop\minecraft.jar!\LZMA\LzmaException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */