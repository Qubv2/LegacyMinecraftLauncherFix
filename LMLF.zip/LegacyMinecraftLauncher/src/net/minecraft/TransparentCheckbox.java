package net.minecraft;

import java.awt.Color;
import javax.swing.JCheckBox;

public class TransparentCheckbox extends JCheckBox {
  private static final long serialVersionUID = 1L;
  
  public TransparentCheckbox(String string) {
    super(string);
    setForeground(Color.WHITE);
  }
  
  public boolean isOpaque() {
    return false;
  }
}


/* Location:              C:\Users\Ziel0ny\Desktop\minecraft.jar!\net\minecraft\TransparentCheckbox.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */