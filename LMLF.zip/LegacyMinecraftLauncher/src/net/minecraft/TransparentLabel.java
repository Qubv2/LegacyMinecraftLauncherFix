package net.minecraft;

import java.awt.Color;
import javax.swing.JLabel;

public class TransparentLabel extends JLabel {
  private static final long serialVersionUID = 1L;
  
  public TransparentLabel(String string, int center) {
    super(string, center);
    setForeground(Color.WHITE);
  }
  
  public TransparentLabel(String string) {
    super(string);
    setForeground(Color.WHITE);
  }
  
  public boolean isOpaque() {
    return false;
  }
}


/* Location:              C:\Users\Ziel0ny\Desktop\minecraft.jar!\net\minecraft\TransparentLabel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */